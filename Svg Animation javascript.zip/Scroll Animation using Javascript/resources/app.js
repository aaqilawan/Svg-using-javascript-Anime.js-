const moonPath = "M39 83C39 128.84 85.5 166 85.5 166C38.2797 166 0 128.84 0 83C0 37.1604 38.2797 0 85.5 0C85.5 0 39 37.1604 39 83Z";
const sunPath = "M171 83C171 128.84 132.72 166 85.5 166C38.2797 166 0 128.84 0 83C0 37.1604 38.2797 0 85.5 0C132.72 0 171 37.1604 171 83Z";

const SunDark = document.getElementById('sun-dark');

let toggle = false;

SunDark.addEventListener('click',() =>{
    let timeline = anime.timeline({
        duration: 750,
        easing :"easeOutExpo"
    })
    .add({
        targets:".sun",
        d:[{
            value:toggle ? sunPath:moonPath
        }]
    })
    .add({
        targets:'#sun-dark',
        rotate:320
    },"-=350")
    .add({
        targets:'section',
        backgroundColor:toggle ? 'rgba(255,255,255)' :'rgb(22,22,22)'
    },'-=350')
    .add({
        targets:'h2',
       color:toggle ? 'rgb(22,22,22)' :'rgba(255,255,255)'
    },'-=350')
    
    if(!toggle){
        toggle =true
    }else{
        toggle=false;
    }
});
